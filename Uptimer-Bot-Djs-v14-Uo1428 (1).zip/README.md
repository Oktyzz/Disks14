<h1 align="center">
   Uptimer Bot - Discord.js v14
</h1>
<h4 align="center">Made with love by Uo#1428 (dont take credit)</h4>

---------
# How To Setup Bot?
- Watch [**Youtbe Video**](https://youtu.be/iTNYbFOMmNA)
# 💖 Support
- ### [ΛLL IN ONΞ™ | Development </>](https://discord.gg/uoaio)
# 💝 Credit
Make sure to credit me!
### [Uo#1428](https://discord.com/users/784649693363306518) | [Website](https://uo1428.tk/) | [Discord](https://discord.gg/uoaio)
#### Profile 
<img align="left" width="100%" style="margin: 0 10px 0 0;" alt=" " src="https://discord.c99.nl/widget/theme-2/784649693363306518.png">
<img align="left" width="100%" style="margin: 0 10px 0 0;" alt=" " src="https://media.discordapp.net/attachments/877859563016159252/879664980218249216/colour_line2.gif">