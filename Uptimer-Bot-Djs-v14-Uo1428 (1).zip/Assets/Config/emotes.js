module.exports = {
  MESSAGE: {
    y: "<a:MarkChecking:992381788028669992>", // yes 
    x: "<:Cross:953158094022668338>", // no
    i: "<:err:985089618657554472>", // info
    l: "" // loading
  }
}