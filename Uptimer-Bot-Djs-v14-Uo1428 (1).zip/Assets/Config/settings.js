module.exports = {
  REPL_USER: true, // true for repl users || false for vps users
  REPL_SETTINGS: {
    EXPRESS: false,
    AUTO_KILL: false
  },
  COMMANDS_LOGS: true,
  COMMANDS_ERROR_LOGS: false,
  SLASH_GLOBLE: true, // true for all servers || false for one server 
}